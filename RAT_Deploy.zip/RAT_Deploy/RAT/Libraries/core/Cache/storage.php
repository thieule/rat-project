<?php
/**
 * @package     T.Platform
 * @subpackage  Cache
 */

defined('T_PLATFORM') or die;

/**
 * Abstract cache storage handler
 *
 * @package     T.Platform
 * @subpackage  Cache
 * @since       5/2014
 */
class TCacheStorage
{
	/**
	 * @var    string  Rawname
	 * @since  5/2014
	 */
	protected $rawname;

	/**
	 * @var    datetime  Now
	 * @since  5/2014
	 */
	public $_now;

	/**
	 * @var    integer  Cache lifetime
	 * @since  5/2014
	 */
	public $_lifetime;

	/**
	 * @var    boolean  Locking
	 * @since  5/2014
	 */
	public $_locking;

	/**
	 * @var    string  Language
	 * @since  5/2014
	 */
	public $_language;

	/**
	 * @var    string  Application name.
	 * @since  5/2014
	 */
	public $_application;

	/**
	 * @var    string  Hash
	 * @since  5/2014
	 */
	public $_hash;

	/**
	 * Constructor
	 *
	 * @param   array  $options  Optional parameters
	 *
	 * @since   5/2014
	 */
	public function __construct($options = array())
	{
		$config = T::getConfig();
		$this->_hash = md5($config->get('secret'));
		$this->_application = (isset($options['application'])) ? $options['application'] : null;
		$this->_language = (isset($options['language'])) ? $options['language'] : 'en-GB';
		$this->_locking = (isset($options['locking'])) ? $options['locking'] : true;
		$this->_lifetime = (isset($options['lifetime'])) ? $options['lifetime'] * 60 : $config->get('cachetime') * 60;
		$this->_now = (isset($options['now'])) ? $options['now'] : time();

		// Set time threshold value.  If the lifetime is not set, default to 60 (0 is BAD)
		// _threshold is now available ONLY as a legacy (it's deprecated).  It's no longer used in the core.
		if (empty($this->_lifetime))
		{
			$this->_threshold = $this->_now - 60;
			$this->_lifetime = 60;
		}
		else
		{
			$this->_threshold = $this->_now - $this->_lifetime;
		}

	}

	/**
	 * Returns a cache storage handler object, only creating it
	 * if it doesn't already exist.
	 *
	 * @param   string  $handler  The cache storage handler to instantiate
	 * @param   array   $options  Array of handler options
	 *
	 * @return  TCacheStorageHandler  A TCacheStorageHandler object
	 *
	 * @since   5/2014
	 */
	public static function getInstance($handler = null, $options = array())
	{
		static $now = null;

		TCacheStorage::addIncludePath(T_PLATFORM . '/core/cache/storage');

		if (!isset($handler))
		{
			$conf = T::getConfig();
			$handler = $conf->get('cache_handler');
			if (empty($handler))
			{
				return TError::raiseWarning(500, JText::_('JLIB_CACHE_ERROR_CACHE_HANDLER_NOT_SET'));
			}
		}

		if (is_null($now))
		{
			$now = time();
		}

		$options['now'] = $now;
		//We can't cache this since options may change...
		$handler = strtolower(preg_replace('/[^A-Z0-9_\.-]/i', '', $handler));

		$class = 'TCacheStorage' . ucfirst($handler);
		if (!class_exists($class))
		{
			// Search for the class file in the TCacheStorage include paths.
			tinclude('core.filesystem.path');
			if ($path = TPath::find(TCacheStorage::addIncludePath(), strtolower($handler) . '.php'))
			{
				include_once $path;
			}
			else
			{
				return TError::raiseWarning(500, JText::sprintf('JLIB_CACHE_ERROR_CACHE_STORAGE_LOAD', $handler));
			}
		}

		return new $class($options);
	}

	/**
	 * Get cached data by id and group
	 *
	 * @param   string   $id         The cache data id
	 * @param   string   $group      The cache data group
	 * @param   boolean  $checkTime  True to verify cache time expiration threshold
	 *
	 * @return  mixed  Boolean  false on failure or a cached data object
	 *
	 * @since   5/2014
	 */
	public function get($id, $group, $checkTime = true)
	{
		return false;
	}

	/**
	 * Get all cached data
	 *
	 * @return  mixed    Boolean false on failure or a cached data object
	 *
	 * @since   5/2014
	 */
	public function getAll()
	{
		if (!class_exists('TCacheStorageHelper', false))
		{
			include_once T_PLATFORM . '/core/cache/storage/helpers/helper.php';
		}
		return;
	}

	/**
	 * Store the data to cache by id and group
	 *
	 * @param   string  $id     The cache data id
	 * @param   string  $group  The cache data group
	 * @param   string  $data   The data to store in cache
	 *
	 * @return  boolean  True on success, false otherwise
	 *
	 * @since   5/2014
	 */
	public function store($id, $group, $data)
	{
		return true;
	}

	/**
	 * Remove a cached data entry by id and group
	 *
	 * @param   string  $id     The cache data id
	 * @param   string  $group  The cache data group
	 *
	 * @return  boolean  True on success, false otherwise
	 *
	 * @since   5/2014
	 */
	public function remove($id, $group)
	{
		return true;
	}

	/**
	 * Clean cache for a group given a mode.
	 *
	 * @param   string  $group  The cache data group
	 * @param   string  $mode   The mode for cleaning cache [group|notgroup]
	 *                          group mode     : cleans all cache in the group
	 *                          notgroup mode  : cleans all cache not in the group
	 *
	 * @return  boolean  True on success, false otherwise
	 *
	 * @since   5/2014
	 */
	public function clean($group, $mode = null)
	{
		return true;
	}

	/**
	 * Garbage collect expired cache data
	 *
	 * @return boolean  True on success, false otherwise.
	 *
	 * @since   5/2014
	 */
	public function gc()
	{
		return true;
	}

	/**
	 * Test to see if the storage handler is available.
	 *
	 * @return   boolean  True on success, false otherwise
	 *
	 * @since    5/2014.
	 */
	public static function test()
	{
		return true;
	}

	/**
	 * Lock cached item
	 *
	 * @param   string   $id        The cache data id
	 * @param   string   $group     The cache data group
	 * @param   integer  $locktime  Cached item max lock time
	 *
	 * @return  boolean  True on success, false otherwise.
	 *
	 * @since   5/2014
	 */
	public function lock($id, $group, $locktime)
	{
		return false;
	}

	/**
	 * Unlock cached item
	 *
	 * @param   string  $id     The cache data id
	 * @param   string  $group  The cache data group
	 *
	 * @return  boolean  True on success, false otherwise.
	 *
	 * @since   5/2014
	 */
	public function unlock($id, $group = null)
	{
		return false;
	}

	/**
	 * Get a cache_id string from an id/group pair
	 *
	 * @param   string  $id     The cache data id
	 * @param   string  $group  The cache data group
	 *
	 * @return  string   The cache_id string
	 *
	 * @since   5/2014
	 */
	protected function _getCacheId($id, $group)
	{
		$name = md5($this->_application . '-' . $id . '-' . $this->_language);
		$this->rawname = $this->_hash . '-' . $name;
		return $this->_hash . '-cache-' . $group . '-' . $name;
	}

	/**
	 * Add a directory where TCacheStorage should search for handlers. You may
	 * either pass a string or an array of directories.
	 *
	 * @param   string  $path  A path to search.
	 *
	 * @return  array  An array with directory elements
	 *
	 * @since   5/2014
	 */
	public static function addIncludePath($path = '')
	{
		static $paths;

		if (!isset($paths))
		{
			$paths = array();
		}

		if (!empty($path) && !in_array($path, $paths))
		{
			tinclude('core.filesystem.path');
			array_unshift($paths, TPath::clean($path));
		}

		return $paths;
	}
}
