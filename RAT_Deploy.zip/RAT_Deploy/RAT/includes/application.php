<?php
// No direct access.
defined('_TEXEC') or die;

//
// T library imports.
//

tinclude('application.application');
tinclude('application.router');
tinclude('application.helper');
tinclude('application.controller');
tinclude('application.model');

