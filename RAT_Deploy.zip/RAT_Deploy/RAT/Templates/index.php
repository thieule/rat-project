<?php
//echo json_encode($errors);
echo json_encode($cn);